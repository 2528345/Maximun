"""IoT gateway service package."""
